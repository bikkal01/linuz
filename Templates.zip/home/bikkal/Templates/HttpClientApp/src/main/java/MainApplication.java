public class MainApplication {
    public static void main(String[] args) {
        String url = "https://jsonplaceholder.typicode.com/posts/1"; // Sample API
        String response = RestClient.fetchData(url);
        System.out.println("API Response: " + response);
    }
}
