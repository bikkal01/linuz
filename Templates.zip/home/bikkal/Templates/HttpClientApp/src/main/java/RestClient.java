import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class RestClient {

    // Logger to capture all activities
    private static final Logger logger = LoggerFactory.getLogger(RestClient.class);

    public static String fetchData(String url) {
        // Create an HTTP client
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            HttpGet request = new HttpGet(url);

            logger.info("Sending GET request to URL: {}", url);

            try (CloseableHttpResponse response = httpClient.execute(request)) {
                int statusCode = response.getCode();
                logger.info("Response received. Status code: {}", statusCode);

                // Get response body
                String responseBody = new String(response.getEntity().getContent().readAllBytes());
                logger.debug("Response body: {}", responseBody);

                return responseBody;
            }
        } catch (Exception e) {
            logger.error("Error occurred while fetching data: {}", e.getMessage());
            return null;
        }
    }
}
