package com.example;

import java.io.IOException;
import java.nio.charset.StandardCharsets;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.hc.client5.http.classic.methods.HttpGet;
import org.apache.hc.client5.http.classic.methods.HttpUriRequestBase;
import org.apache.hc.client5.http.impl.classic.CloseableHttpClient;
import org.apache.hc.client5.http.impl.classic.CloseableHttpResponse;
import org.apache.hc.client5.http.impl.classic.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@WebServlet("/apiClient")
public class ApiClientServlet extends HttpServlet {
    private static final Logger logger = LoggerFactory.getLogger(ApiClientServlet.class);

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String apiUrl = "https://jsonplaceholder.typicode.com/posts";  // Example API URL

        // Create an instance of HttpClient
        try (CloseableHttpClient httpClient = HttpClients.createDefault()) {
            // Prepare the HTTP GET request (HttpGet is a subclass of HttpUriRequestBase)
            HttpUriRequestBase request = new HttpGet(apiUrl);

            // Execute the request and handle the response
            try (CloseableHttpResponse response = httpClient.execute(request)) {
                // Read the response content as a string
                String responseString = new String(response.getEntity().getContent().readAllBytes(), StandardCharsets.UTF_8);

                // Log the successful API call and response
                logger.info("Successfully called API: {}", apiUrl);
                logger.debug("Response from API: {}", responseString);

                // Set the response content type and write the response to the client
                resp.setContentType("application/json");
                resp.getWriter().write(responseString);
            } catch (Exception e) {
                // Log the error and send a server error response
                logger.error("Error while calling API: {}", apiUrl, e);
                resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to fetch API response");
            }
        } catch (IOException e) {
            // Log the error if the HTTP client creation fails
            logger.error("Error with HTTP client", e);
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to create HTTP client");
        }
    }
}
